self.assetsManifest = {
  "version": "mG7ICV75",
  "assets": [
    {
      "hash": "sha256-JVU6b24vF454OI2stRiMRzMEdL0NeaSoqqrSXRbJiUc=",
      "url": "WerewolfAchievementViewer.styles.css"
    },
    {
      "hash": "sha256-0fT5DLMa1voamFmX5/f/aY8oct7a5CLEOHu2Tdn6oCA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.5fnpqqr84r.wasm"
    },
    {
      "hash": "sha256-jB/Gf1i7eXuQqAzqY/ZONe+hrW3x94pYZlL+G0Cv7Co=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.0prlth0hc4.wasm"
    },
    {
      "hash": "sha256-9qvZnWqeS+fMA8YvTNodhzUbzRRBVM0BQYsP6BCGrRA=",
      "url": "_framework/Microsoft.AspNetCore.Components.q4uu8itskr.wasm"
    },
    {
      "hash": "sha256-V/8lrAHQfJYsJtV+bKRHL6fmMFhJhAOyoTNfGTbwTdQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.7sm4vp77d1.wasm"
    },
    {
      "hash": "sha256-M/V9DIZ9otM7/qEt+xn3wagkoRiLOf4JMPyDoo6WUM8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.n3roazub70.wasm"
    },
    {
      "hash": "sha256-XQykit2HYxnB0emmOc5bra6XuZq3KgCfazi8kFAErDs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.jgtmx19396.wasm"
    },
    {
      "hash": "sha256-dmvVxmgmr5Q1PLvNIjXQnF2nCWar7lVbE7b/friBcCw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ea8ydkpa40.wasm"
    },
    {
      "hash": "sha256-wPj/fOeoE7JKOgIYh6OIvl/k3Iw6EPDmmXDjtnQ6rJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g0r86u4i0h.wasm"
    },
    {
      "hash": "sha256-6UXGcpnRVdREm/wLy0F4/SMe6bufvlF3kBHQ/4OfswE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.lp9rwj90hb.wasm"
    },
    {
      "hash": "sha256-5E3YJsqbWNbv+OJiZ1kCoV5czf1fXeUBZBKig0eHQKs=",
      "url": "_framework/Microsoft.Extensions.Logging.km3zhtnk76.wasm"
    },
    {
      "hash": "sha256-2xzw4xsXcqL7SQ6R76v+GZrC7ZqwjD2SQaJrbh6IFlc=",
      "url": "_framework/Microsoft.Extensions.Options.xtnmlnlmnd.wasm"
    },
    {
      "hash": "sha256-+HoDX+e0bGwi8OjZvR5ZpN4OxMMBE8OX4f2wu++wdqE=",
      "url": "_framework/Microsoft.Extensions.Primitives.geznw6vy35.wasm"
    },
    {
      "hash": "sha256-hbzWuXrlepIqY/y+nQ2ZAFer2/njy1dc+Y4LUaAaL5E=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.p386u0jty9.wasm"
    },
    {
      "hash": "sha256-j93883TLWrUsylBnXBVb1aCW34uImOVFvkmgV7v8tx0=",
      "url": "_framework/Microsoft.JSInterop.bdr89uoxtd.wasm"
    },
    {
      "hash": "sha256-n2tMK4/qjvYtyASQpA6tiPfmLzwwATenvqHiNHsUYYQ=",
      "url": "_framework/NewTsWw.Models.Werewolf.7i1chymwbu.wasm"
    },
    {
      "hash": "sha256-W/vtZ+rFMp6Ad2RptSMexhqjuMxduiExdf84B5Ey2SE=",
      "url": "_framework/System.Collections.Concurrent.15jj5izto0.wasm"
    },
    {
      "hash": "sha256-x6eV1PfrlPOpcKSBWqKosZTrwL8bP3UXZh+JyB58rB0=",
      "url": "_framework/System.Collections.Immutable.hyi9w42nb9.wasm"
    },
    {
      "hash": "sha256-hiCNLBMli9ZrBjl0l9NVvcXG36xkGJF/znLqDS6yYxs=",
      "url": "_framework/System.Collections.NonGeneric.6o2wb88be1.wasm"
    },
    {
      "hash": "sha256-d00D2KruPQeon9v2GopHlhTcTYiYDKEGM1QQkDJoY8I=",
      "url": "_framework/System.Collections.Specialized.1qiv63tbbk.wasm"
    },
    {
      "hash": "sha256-wqDwKiVLixWhAygffvtSFZh7+23r6VZ0B7/yk/kp1X0=",
      "url": "_framework/System.Collections.u4p00wuuze.wasm"
    },
    {
      "hash": "sha256-EAH+AceUor/I/HXJqamb4SsUKfns37g1AqawR+Ivn4A=",
      "url": "_framework/System.ComponentModel.Annotations.kzvca67pzy.wasm"
    },
    {
      "hash": "sha256-ecg1DAg+U+JKY3gJ25MJwpgY3/FTojp6Hj+9mroE5GY=",
      "url": "_framework/System.ComponentModel.Primitives.hiizc154md.wasm"
    },
    {
      "hash": "sha256-bK1TfzH7+36iiDER+vYXp6Dbjn6ENO5fAXiNDVb6Vn8=",
      "url": "_framework/System.ComponentModel.TypeConverter.ojhnqsdiby.wasm"
    },
    {
      "hash": "sha256-4qXZbapsDZssS5DvMcw49dIUrVfBIKsZ0zbsHsukBPQ=",
      "url": "_framework/System.ComponentModel.m3ms7gmx60.wasm"
    },
    {
      "hash": "sha256-Y4NIMfrZ43sMuvvoL2ezi5KGYN2qkqchH7s9Y9MJskw=",
      "url": "_framework/System.Console.7n67arx7bd.wasm"
    },
    {
      "hash": "sha256-x7GpRObgn1vqZTVSQPKWaJmi89DhNfSOuwKn+3FVG+Q=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ps3c82qvas.wasm"
    },
    {
      "hash": "sha256-uEVVMYx7abWgasKfPzSB6wOMoCpVEVv4EcEAOCa4ph0=",
      "url": "_framework/System.IO.Pipelines.0uhw8kopg1.wasm"
    },
    {
      "hash": "sha256-Sn8lVq1qZmHZon7E+2oZnLs+A7r0mY3XQWf7tUQ76zQ=",
      "url": "_framework/System.Linq.emxiaj9wzk.wasm"
    },
    {
      "hash": "sha256-ON7LdppuSiK+Los/mM4y9ImsccszpWRjTZxs3WPaors=",
      "url": "_framework/System.Memory.s3k4fpjtbw.wasm"
    },
    {
      "hash": "sha256-uaDJXUjtVrPMO5gJ5/dikCyyZpnq9v69Cd/kmBYzqkE=",
      "url": "_framework/System.Net.Http.Json.firoqhkdnq.wasm"
    },
    {
      "hash": "sha256-Y3OEH1gIRxE6V1FgXR6ojxU1XIoYIMuVEdyCapzAa1w=",
      "url": "_framework/System.Net.Http.j8ritvws54.wasm"
    },
    {
      "hash": "sha256-nezaQh05iG5l4rQswqNPl/zET8UwMn5b44CpxdCrhyQ=",
      "url": "_framework/System.Net.Primitives.9x72ktbyas.wasm"
    },
    {
      "hash": "sha256-wNfPvrHDu12m8nAsDGzNZQk23FT+Jj3h9Ewtkzk8Yuc=",
      "url": "_framework/System.ObjectModel.wgm2i2b0yp.wasm"
    },
    {
      "hash": "sha256-qMrRj7mJTd65uK/+1/gHsQLIHFJnChQi1+bhXKf1T1s=",
      "url": "_framework/System.Private.CoreLib.cbsgy0yfde.wasm"
    },
    {
      "hash": "sha256-bY//cPcK0yaHCrtl8kBf3CXyN0KKZqEou0IPz3dxRNU=",
      "url": "_framework/System.Private.Uri.7rsgzeo09z.wasm"
    },
    {
      "hash": "sha256-uo4WQ39eiOB+w/weMzCVCfXQey09VlzpTm+e6aR83IA=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.era55l3sbb.wasm"
    },
    {
      "hash": "sha256-UUxeWDj+5r7mVFbkFoPis2kw/iyOFbPvOBXY7TaV048=",
      "url": "_framework/System.Runtime.jz3ib14c1q.wasm"
    },
    {
      "hash": "sha256-KD5saNzkpUD3A/RXlqBthi/qKA3Sk2nZuNvyfL9+EWc=",
      "url": "_framework/System.Text.Encodings.Web.wmi2z5c0zd.wasm"
    },
    {
      "hash": "sha256-mggrw7yPAeT+OCcPiWfm+/BuEIMoLo9FBPRUN+Bt+cM=",
      "url": "_framework/System.Text.Json.eumrjaz7x3.wasm"
    },
    {
      "hash": "sha256-bPlopc5D66ZLknzJ5PcpsBvpXxGmy7xL7+4gm/cjTdc=",
      "url": "_framework/System.Text.RegularExpressions.gjrc7fe0iy.wasm"
    },
    {
      "hash": "sha256-v1DeJU321NUwk3KJ0Lf8lQA3zwRfrxNommmMBs1s3Gk=",
      "url": "_framework/System.f0fr8djds0.wasm"
    },
    {
      "hash": "sha256-f9FLae1KdMDo0/1sEplGE2cSOYWNUMEVeNxVMBoSNpQ=",
      "url": "_framework/WerewolfAchievementViewer.5vi0nytvuc.wasm"
    },
    {
      "hash": "sha256-HcEzWdVtidPo1Tbpagl5dd3ieaj+K7LUzrostp7YSwk=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-5TAd2is0AgjjYIAuEN8Bd5ZPoTk8dKE9RRtIQr4H5Lw=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-89jyB8DlCnV2BPMV477jOe1Sm0WXwVf8RuoSPsj4Ym8=",
      "url": "_framework/dotnet.native.3c4wvb350q.wasm"
    },
    {
      "hash": "sha256-LX9rFEWGVxhkOkAVPG0w5RxPwzPBlEUz6dQNjWS7M+M=",
      "url": "_framework/dotnet.native.hvg7u8bimp.js"
    },
    {
      "hash": "sha256-dCmS9Zx4egtLYSUgTI3R6gMS+Yg8MkzxW1CgEMJKAEw=",
      "url": "_framework/dotnet.runtime.cymp1amu5g.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-ex/qxQux/bACLmA1VWlvhyPAvd//lC6PSwh02zUOkn8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-gEDWmCSOLfRULkq60/+ICRPXUJg8DWgLXjl+Pn9xukU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-vJ1F/TdU9hM6WPbMWLOKVuisOFPC7+oh/d2qqkWgqEY=",
      "url": "js/app.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-mHrMq0gOFb4mzagVRnIVmx7cjTYKen5ZZDLQ/U/caXc=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-nMjR6OWt0R1W0HwNZweTLQqJyVyVYpOnWAY5RlOdoNA=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-9sttTsUF83IAAHBqS2eicgK+5O7gkCl2WR1tR+pVSM0=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-8ZjTrw9T+uBZDw0XvWd2HwDCyIVzEiaMt8zgdZJF9A0=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-N/XiHFHj/6WrHqElEecFWWOU+uVp78wxYwpsIHPAcrI=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-yZyJMzoHmkM63EjTeiuEFDeiGRAODuSCDVpmcimUQAs=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-ZkA5b7repYSbwJroTLrfDNBjFP0WOq2b+9bMUyV4P3Q=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-6iTd2rJy9+WJLbJZTYynmaKttafhfp+ufMgDsfh4ifU=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-bLPTtRACgdFWc3KzGLE80QHfcGXMOy8aNT7A7rop5ng=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-AUj6dRs7y3Q64SiTYf1s6lT8noTC5yAHt7dwjng096U=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
